姜小姜自动点名系统功能简介：
1. 解压zip包以后，使用dart自带的Chromium(Dartium)浏览器打开index.html文件。
2. 点击点名即可随机点名啦！（student11-student17）
3. 程序默认为class1这节课的学生，如果想换课可以在下拉菜单中选择class2这节课，然后再点击点名，即可随机点另一节课同学的名字（student21-student27）。